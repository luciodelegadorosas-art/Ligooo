# ReplyMate AI

Aplicación web sencilla que:
- permite elegir una captura desde la galería;
- envía la imagen al backend;
- el backend mantiene la clave de OpenAI fuera del navegador;
- una IA analiza el chat;
- genera 3 respuestas según: Caliente, Enamorar, Chistoso, Salvar o Seguro.

## Requisitos

Node.js 18+ recomendado.

## Instalar

```bash
npm install
```

Copia `.env.example` como `.env` y añade tu clave:

```text
OPENAI_API_KEY=tu_clave
```

## Ejecutar

```bash
npm start
```

Abre:

http://localhost:3000

## Publicarlo en Internet

Puedes desplegar este proyecto en un hosting que soporte Node.js. Configura `OPENAI_API_KEY` como variable de entorno del servidor y no la subas al repositorio.

El HTML se sirve desde `public/`. El endpoint privado es `POST /api/reply`.

## Seguridad

La clave de API nunca se envía al navegador. El navegador solo llama a `/api/reply`.
Para producción conviene añadir autenticación, rate limiting, límites de tamaño y controles de abuso del proveedor de hosting/API.
